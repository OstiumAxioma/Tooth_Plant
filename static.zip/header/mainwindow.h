#ifndef MAINWINDOW_H
#define MAINWINDOW_H

// VTK模块初始化 - 解决 "no override found for 'vtkRenderer'" 错误
#include <vtkAutoInit.h>
VTK_MODULE_INIT(vtkRenderingOpenGL2)
VTK_MODULE_INIT(vtkInteractionStyle)

#include <QMainWindow>
#include <memory>
#include <vtkSmartPointer.h>

QT_BEGIN_NAMESPACE
class QAction;
class QMenu;
class QMenuBar;
class QStatusBar;
class QToolBar;
class QLabel;
class QSlider;
class QVBoxLayout;
QT_END_NAMESPACE

class QVTKOpenGLWidget;
class vtkRenderer;
template <class T> class vtkSmartPointer;

class ComponentCreator;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void createActions();
    void createMenus();
    void createToolBars();
    void createStatusBar();
    void setupSimpleWidget();
    void setupVTKWidget();
    void updateValueLabels();
    QWidget* buildControls();
    QWidget* buildRenderArea();
    void updateActorFromControls();
    double currentLength() const;

private:
    // UI组件
    QVTKOpenGLWidget *vtkWidget;
    QWidget *renderContainer;
    QVBoxLayout *renderLayout;
    QLabel *renderPlaceholder;
    QMenu *fileMenu;
    QMenu *helpMenu;
    QToolBar *fileToolBar;
    QAction *exitAct;
    QAction *aboutAct;

    // 渲染器和组件生成器
    vtkSmartPointer<vtkRenderer> renderer;
    std::unique_ptr<ComponentCreator> componentCreator;

    // 控制滑块
    QSlider *startSliders[3];
    QSlider *endSliders[3];
    QSlider *radiusSlider;
    QSlider *neckHeightSlider;
    QSlider *bodyHeightSlider;
    QSlider *headHeightSlider;
    QSlider *baseTopRadiusSlider;
    QSlider *resolutionSlider;
    QSlider *threadDepthSlider;
    QSlider *threadTurnsSlider;
    QSlider *abutmentBottomRadiusSlider;
    QSlider *abutmentTopRadiusSlider;
    QSlider *abutmentAngleSlider;
    QSlider *abutmentAzimuthSlider;
    QSlider *abutmentLengthSlider;
    QLabel *startValueLabels[3];
    QLabel *endValueLabels[3];
    QLabel *radiusValueLabel;
    QLabel *neckHeightValueLabel;
    QLabel *bodyHeightValueLabel;
    QLabel *headHeightValueLabel;
    QLabel *baseTopRadiusValueLabel;
    QLabel *resolutionValueLabel;
    QLabel *threadDepthValueLabel;
    QLabel *threadTurnsValueLabel;
    QLabel *abutmentBottomRadiusValueLabel;
    QLabel *abutmentTopRadiusValueLabel;
    QLabel *abutmentAngleValueLabel;
    QLabel *abutmentAzimuthValueLabel;
    QLabel *abutmentLengthValueLabel;
    QLabel *abutmentCenterInfoLabel;
    QLabel *lengthInfoLabel;
};

#endif // MAINWINDOW_H
